#include "RPN.hpp"

int calculate(int a, int b, char op)
{
    if (op == '+')
        return a + b;
    if (op == '-')
        return a - b;
    if (op == '*')
        return a * b;
    if (op == '/')
        return a / b;
    throw std::runtime_error("Error");
}

int is_operator(int c)
{
    if (c == '-' || c == '+' || c == '*' || c == '/')
        return (1);
    return 0;
}

