#ifndef RPN_HPP
#define RPN_HPP

#include <iostream>
#include <stack>

int calculate(int a, int b, char op);
int is_operator(int c);

#endif