#include "RPN.hpp"

int main(int ac, char **av)
{
    if (ac != 2)
        return (std::cerr << "Error\n", 1);
    std::string     input(av[1]);
    std::stack<int> stack;
    for (size_t i = 0; i < input.length(); i++)
    {
        if (input[i] == ' ')
            continue;
        if (isdigit(input[i]))
        {
            stack.push(input[i] - '0');
        }else if (is_operator(input[i]))
        {
            if (stack.size() < 2)
                return (std::cerr << "Error\n", 1);
            int b = stack.top();
            stack.pop();
            int a = stack.top();
            stack.pop();
            if (input[i] == '/' && b == 0)
                return (std::cerr << "Error\n", 1);
            stack.push(calculate(a, b, input[i]));
        }else
            return (std::cerr << "Error\n", 1);
    }
    if (stack.size() != 1)
        return (std::cerr << "Error\n", 1);
    std::cout << stack.top() << '\n';
}