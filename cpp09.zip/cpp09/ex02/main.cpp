#include "PmergeMe.hpp"

template <typename T>
void    print(T &arr)
{
    for (size_t i = 0; i < arr.size(); i++)
    {
        std::cout << arr[i];
        if (i < arr.size() - 1)
            std::cout << " ";
    }
    std::cout << '\n';
}

int main(int ac, char **av)
{
    if (ac != 2)
        return (std::cerr << "Error\n", 1);
    
    double start_vec, end_vec, start_deq, end_deq;
    int key = 0;
    std::vector<int> arr;
    start_vec = clock();
    create_arr(av[1], arr);
    std::vector<int> sorted_arr;
    if (!std::is_sorted(arr.begin(), arr.end()))
        sorted_arr = ft_sort(arr, arr.size());
    end_vec  = clock();

    std::deque<int> arr1;
    start_deq = clock();
    create_arr(av[1], arr1);
    std::deque<int> sorted_arr1;
    if (!std::is_sorted(arr1.begin(), arr1.end()))
    {
        std::deque<int> sorted_arr1 = ft_sort(arr1, arr1.size());
        key = 1;
    }
    end_deq  = clock();

    double time_vec = (end_vec - start_vec) / 1000;
    double time_deq = (end_deq - start_deq) / 1000;

    std::cout << "Before: ";
    print(arr);
    std::cout << "After: ";
    if (key)
        print(sorted_arr);
    else
        print(arr);

    std::cout << "Time to process a range of " << arr.size() 
              << " elements with std::vector : " << time_vec << " us\n";
    std::cout << "Time to process a range of " << arr1.size() 
              << " elements with std::deque : " << time_deq << " us\n";
    if (!std::is_sorted(sorted_arr.begin(),sorted_arr.end()) || !std::is_sorted(sorted_arr1.begin(),sorted_arr1.end()))
        std::cout << "error\n";
    return 0;
}