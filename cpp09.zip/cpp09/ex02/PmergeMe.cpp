#include "PmergeMe.hpp"

void insert_sorted(std::deque<int>& chain, int value)
{
    std::deque<int>::iterator pos = std::lower_bound(chain.begin(), chain.end(), value);

    chain.insert(pos, value);
}

void insert_sorted(std::vector<int>& chain, int value)
{
    std::vector<int>::iterator pos = std::lower_bound(chain.begin(), chain.end(), value);

    chain.insert(pos, value);
}

std::deque<int>    ft_sort(std::deque<int> arr, size_t size)
{
    if (arr.size() == 1)
        return arr;
    int last = 0;
    std::deque<std::pair<int, int> > pairs;
    for (size_t i = 0; i < size - (size % 2 == 0 ? 0 : 1); i += 2)
    {
        int a = arr[i];
        int b = arr[i + 1];
        if (a > b)
            pairs.push_back(std::pair<int, int>(a ,b));
        else
            pairs.push_back(std::pair<int, int>(b ,a));
    }
    if ((size % 2) != 0)
        last = arr.back();

    std::deque<int> big;
    for (size_t i = 0; i < pairs.size(); i++)
        big.push_back(pairs[i].first);

    std::deque<int> chain = ft_sort(big, big.size());

    for (size_t i = 0; i < pairs.size(); i++)
        insert_sorted(chain, pairs[i].second);

    if ((size % 2) != 0)
        insert_sorted(chain, last);
    return chain;
}

std::vector<int>    ft_sort(std::vector<int> arr, size_t size)
{
    if (arr.size() == 1)
        return arr;
    int last = 0;
    std::vector<std::pair<int, int> > pairs;
    for (size_t i = 0; i < size - (size % 2 == 0 ? 0 : 1); i += 2)
    {
        int a = arr[i];
        int b = arr[i + 1];
        if (a > b)
            pairs.push_back(std::pair<int, int>(a ,b));
        else
            pairs.push_back(std::pair<int, int>(b ,a));
    }
    if ((size % 2) != 0)
        last = arr.back();

    std::vector<int> big;
    for (size_t i = 0; i < pairs.size(); i++)
        big.push_back(pairs[i].first);

    std::vector<int> chain = ft_sort(big, big.size());

    for (size_t i = 0; i < pairs.size(); i++)
        insert_sorted(chain, pairs[i].second);

    if ((size % 2) != 0)
        insert_sorted(chain, last);
    return chain;
}

int ft_strlen(std::string &str)
{
    size_t i = 0;
    while (i < str.length() && str[i] == '0')
        i++;
    if (i == str.length() && !str.empty())
        return 1;
    return str.length() - i;
}

int is_valid(std::string str)
{
    for (size_t i = 0; i < str.length(); ++i)
    {
        if (!std::isdigit(str[i]))
            return 0;
    }
    return 1;
}

void create_arr(std::string input, std::vector<int> &arr)
{
    std::stringstream   stream(input);
    std::string         line;
    double              value;
    while (getline(stream, line, ' '))
    {
        if (line.empty())
            continue ;
        value = std::strtol(line.c_str(), NULL, 10);
        if (ft_strlen(line) < 12 && value >= 0 && value <= INT_MAX
            && is_valid(line) && std::find(arr.begin(), arr.end(), static_cast<int>(value)) == arr.end())
        {
            arr.push_back(static_cast<int>(value));
        }else
        {
            std::cerr << "Error\n";
            exit(1);
        }
    }
}

void create_arr(std::string input, std::deque<int> &arr)
{
    std::stringstream   stream(input);
    std::string         line;
    double              value;
    while (getline(stream, line, ' '))
    {
        if (line.empty())
            continue ;
        value = std::strtol(line.c_str(), NULL, 10);
        if (ft_strlen(line) < 12 && value >= 0 && value <= INT_MAX
            && is_valid(line) && std::find(arr.begin(), arr.end(), static_cast<int>(value)) == arr.end())
        {
            arr.push_back(static_cast<int>(value));
        }else
        {
            std::cerr << "Error\n";
            exit(1);
        }
    }
}