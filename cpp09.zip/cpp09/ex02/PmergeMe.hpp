#ifndef PMERGEME_HPP
#define PMERGEME_HPP

#include <algorithm>
#include <iostream>
#include <sstream>
#include <vector>
#include <time.h>
#include <deque>

void                create_arr(std::string input, std::vector<int> &arr);
void                create_arr(std::string input, std::deque<int> &arr);
void                insert_sorted(std::vector<int>& chain, int value);
void                insert_sorted(std::deque<int>& chain, int value);
std::vector<int>    ft_sort(std::vector<int> arr, size_t size);
std::deque<int>     ft_sort(std::deque<int> arr, size_t size);
int                 ft_strlen(std::string &str);
int                 is_valid(std::string str);

#endif