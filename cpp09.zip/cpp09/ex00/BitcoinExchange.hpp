#include <algorithm>
#include <iostream>
#include <fstream>
#include <map>

typedef std::multimap<std::string, float>::iterator iterator;

int validating_line(std::string line);