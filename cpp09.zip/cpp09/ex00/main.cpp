#include "BitcoinExchange.hpp"

void    create_map(std::multimap<std::string, float> &map, std::string info)
{
    int         cama = info.find(',');
    std::string date = info.substr(0, cama);
    std::string exchange_rate = info.substr(cama + 1);
    float       rate_number = std::strtod(exchange_rate.c_str(), NULL);
    map.insert(std::make_pair(date, rate_number));
}

int read_line(std::string filename, std::multimap<std::string, float> &data)
{
    std::ifstream input(filename);
    if (!input.is_open())
        return (std::cerr << "error in opening file data.csv\n", 0);
    std::string text;
    if (!std::getline(input, text))
        return (std::cerr << "error in getline\n", 0);
    while (std::getline(input, text))
        create_map(data, text);
    return 1;
}

int run_calculation(std::multimap<std::string, float> &data, std::string &date_dest, float &value_dest)
{
    iterator it = data.lower_bound(date_dest);
    if (it == data.end())
        it--;
    else if (it->first != date_dest)
    {
        if (it == data.begin())
            return (std::cerr << "Error: no earlier date available\n", 0);
        it--;
    }
    std::cout << std::fixed <<std::setprecision(2) << date_dest << " => " << value_dest << " = " << (value_dest * it->second) << '\n';
    return (1);
}

int procecing_input(std::multimap<std::string, float> &data, std::string input)
{
    std::string     line;
    std::ifstream   stream(input);
    std::string     date;
    float           value;
    if (!stream.is_open())
        return (std::cerr << "error in files opening\n", 0);
    std::getline(stream, line);
    if (line != "date | value")
        return (std::cerr << "error wrong format file\n", 0);
    while (std::getline(stream, line))
    {
        if (validating_line(line))
        {
            date = line.substr(0, line.find(" | "));
            value = std::strtof(line.substr(line.find(" | ") + 3).c_str(), NULL);
            run_calculation(data, date, value);
        }
    }
    return 1;
}

int main(int ac, char **av)
{
    if (ac != 2)
        return (std::cerr << "try this -> btc input.txt\n", 1);
    std::multimap<std::string, float> data;
    if (!read_line("data.csv", data))
        return 1;
    if (!procecing_input(data, av[1]))
        return 1;
    return 0;
}