#include "BitcoinExchange.hpp"

int allnumber(std::string str, int point)
{
    int i = 0;
    while(str[i])
    {
        if ((str[i] > '9' || str[i] < '0') && i != point)
            return 0;
        i++;
    }
    return 1;
}

int validating_date(std::string date)
{
    if (std::count(date.begin(), date.end(), '-') != 2)
        return (0);
    size_t first_dash = date.find('-');
    size_t second_dash = date.find('-', first_dash + 1);
    std::string year = date.substr(0, first_dash);
    std::string month = date.substr(first_dash + 1, second_dash - first_dash - 1);
    std::string day = date.substr(second_dash + 1);
    if (!allnumber(year, -1) || !allnumber(month, -1) || !allnumber(day, -1))
        return (0);
    if (year.length() != 4 || ((std::strtof(year.c_str(), NULL) > 2026) || (std::strtof(year.c_str(), NULL) < 1)))
        return (0);
    if (month.length() != 2 || ((std::strtof(month.c_str(), NULL) > 12) || (std::strtof(month.c_str(), NULL) < 1)))
        return (0);
    if (day.length() != 2 || ((std::strtof(day.c_str(), NULL) > 31) || (std::strtof(day.c_str(), NULL) < 1)))
        return (0);
    return 1;
}

int validating_value(std::string value, std::string &error)
{
    int dot_count = std::count(value.begin(), value.end(), '.');
    if (dot_count > 1)
        return (error = "more than 1 point",0);
    for (size_t i = 0; i < value.length(); i++)
    {
        if (!std::isdigit(value[i]) && value[i] != '.')
        {
            if (value[i] == '-' && i == 0)
                return (error = "not a positive number",0);
            return (error = "bad value",0);
        }
    }
    float number = std::strtof(value.c_str(), NULL);
    if (number < 0)
        return (error = "not a positive number",0);
    if (number > 1000)
        return (error = "too large a number",0);
    return 1;
}

int validating_line(std::string line)
{
    std::string date;
    std::string value;
    std::string error;
    if (std::count(line.begin(), line.end(), '|') != 1
        || std::count(line.begin(), line.end(), ' ') > 2
        || line.find(" | ") == std::string::npos)
        return (std::cerr << "Error: bad input => " << line <<'\n', 0);
    size_t  pipe = line.find(" | ");
    date = line.substr(0, pipe);
    value = line.substr(pipe + 3);
    if(!validating_date(date))
        return (std::cerr << "Error: bad date => " << date <<'\n', 0);
    if(!validating_value(value, error))
        return (std::cerr << "Error: " << error <<" => " << value << '\n', 0);
    return (1);
}
